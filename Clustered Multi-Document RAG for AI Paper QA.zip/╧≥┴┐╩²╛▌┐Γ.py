import os
import json
import numpy as np
import faiss
import pickle
from tqdm import tqdm

input_file = "chunks_with_emb.jsonl"

index_file = "faiss_index.bin"
mapping_file = "metadata.pkl"

embeddings = []
metadata = []

print("Loading embeddings...")

with open(input_file, "r", encoding="utf-8") as f:

    for line in tqdm(f):

        data = json.loads(line)

        emb = np.array(data["embedding"], dtype=np.float32)

        embeddings.append(emb)

        metadata.append({
            "chunk_id": data["chunk_id"],
            "title": data.get("paper_title",""),
            "category": data.get("category",""),
            "page": data.get("page_number",0),
            "text": data["text"]
        })

embeddings = np.vstack(embeddings)

dimension = embeddings.shape[1]

print("Total vectors:", len(embeddings))
print("Dimension:", dimension)

# ===== FAISS index =====

nlist = 100

quantizer = faiss.IndexFlatIP(dimension)

index = faiss.IndexIVFFlat(
    quantizer,
    dimension,
    nlist,
    faiss.METRIC_INNER_PRODUCT
)

print("Training index...")

index.train(embeddings)

print("Adding vectors...")

index.add(embeddings)

print("Saving index...")

faiss.write_index(index, index_file)

with open(mapping_file, "wb") as f:
    pickle.dump(metadata, f)

print("Done")