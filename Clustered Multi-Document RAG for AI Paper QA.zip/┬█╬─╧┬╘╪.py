import arxiv
import os
import json

# ======== 配置区域 ========
save_dir = "papers_by_category"
os.makedirs(save_dir, exist_ok=True)

# 每个方向抓取数量
papers_per_category = 30  # 你可以改成 20~50

years_range = (2024, 2025)  # 只抓这些年份的论文

# 方向及关键词
categories = {
    "RAG": [
        "retrieval augmented generation",
        "graph rag",
        "agentic rag"
    ],
    "LLM": [
        "large language model reasoning",
        "multi agent llm"
    ],
    "Hallucination": [
        "llm hallucination",
        "hallucination detection",
        "factuality llm"
    ],
    "Graph_LLM": [
        "knowledge graph llm",
        "graph reasoning llm"
    ],
    "Embodied_AI": [
        "embodied ai",
        "vision language action",
        "robot foundation model"
    ],
    "Multimodal_LLM": [
        "vision language model",
        "multimodal llm",
        "video llm",
        "audio llm"
    ]
}

# 可选：顶会关键词
conference_keywords = [
    "NeurIPS", "ICML", "ICLR", "ACL", "EMNLP", "CVPR", "ICCV", "AAAI", "SIGIR", "KDD"
]

# ======== 下载逻辑 ========
all_metadata = []
downloaded_ids = set()

for category, keywords in categories.items():
    cat_dir = os.path.join(save_dir, category)
    os.makedirs(cat_dir, exist_ok=True)
    count = 0

    print(f"\n===== Downloading category: {category} =====")
    for key in keywords:
        query = f'({key}) AND ({ " OR ".join(conference_keywords) })'
        search = arxiv.Search(
            query=query,
            max_results=100,
            sort_by=arxiv.SortCriterion.Relevance
        )

        for result in search.results():
            if count >= papers_per_category:
                break

            # 按年份过滤
            year = result.published.year
            if year < years_range[0] or year > years_range[1]:
                continue

            # 去重
            paper_id = result.get_short_id()
            if paper_id in downloaded_ids:
                continue

            # 下载 PDF
            try:
                pdf_path = os.path.join(cat_dir, paper_id + ".pdf")
                result.download_pdf(dirpath=cat_dir)
                print(f"[{category}] {count+1}: {result.title}")

                # 保存 metadata
                all_metadata.append({
                    "arxiv_id": paper_id,
                    "title": result.title,
                    "authors": [a.name for a in result.authors],
                    "published": result.published.strftime("%Y-%m-%d"),
                    "summary": result.summary,
                    "pdf_path": pdf_path,
                    "category": category
                })

                downloaded_ids.add(paper_id)
                count += 1
            except Exception as e:
                print(f"Failed: {result.title} - {e}")

        if count >= papers_per_category:
            break

# 保存总 metadata.json
with open(os.path.join(save_dir, "metadata.json"), "w", encoding="utf-8") as f:
    json.dump(all_metadata, f, ensure_ascii=False, indent=2)

print("\nAll categories done!")