import os
import json
import random
import time
from collections import defaultdict
from tqdm import tqdm

# ======== 配置 ========
input_file = "chunks_clustered.jsonl"
output_file = "cluster_labels.json"

# 选择你的API配置（二选一）
# # 方案1：OpenAI（科学上网 needed）
# API_KEY = "sk-91c002d7203543c98c79463e20d5e5ea"
# BASE_URL = None  # 默认OpenAI官方
# MODEL = "gpt-3.5-turbo"  # 或 "gpt-4o"（更快更准）

# 方案2：通义千问（国内可用，推荐）
API_KEY = "sk-91c002d7203543c98c79463e20d5e5ea"
BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
MODEL = "qwen3-max"  # 或 "qwen-plus", "qwen-max"

os.environ["OPENAI_API_KEY"] = API_KEY

from openai import OpenAI

# 初始化客户端（增加超时）
client = OpenAI(
    base_url=BASE_URL,
    timeout=60.0,  # 60秒超时
    max_retries=3  # 自动重试3次
)

samples_per_cluster = 3  # 减少到3个样本，加快响应
max_text_len = 200  # 每段文本限制200字符


def generate_label(cluster_id, texts, max_retries=3):
    """调用LLM生成cluster标签（带重试）"""
    prompt = f"""These text chunks belong to the same topic:

{chr(10).join([f"{i + 1}. {text}" for i, text in enumerate(texts)])}

Summarize the topic in 2-5 words. Return ONLY the label:"""

    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": "You summarize academic topics concisely."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=15
            )
            label = response.choices[0].message.content.strip()
            # 清理
            label = label.strip('"\'').split('.')[0].split('\n')[0]
            if len(label) > 50:  # 太长则截断
                label = label[:50]
            return label

        except Exception as e:
            print(f"   ⚠️  Attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # 指数退避
            else:
                return f"Cluster_{cluster_id}"


# ======== 读取数据 ========
print("📖 读取聚类数据...")
clusters = defaultdict(list)

with open(input_file, "r", encoding="utf-8") as f:
    for line in tqdm(f, desc="加载"):
        try:
            data = json.loads(line)
            clusters[data["cluster_id"]].append(data["text"])
        except:
            continue

print(f"✅ 发现 {len(clusters)} 个clusters")

# ======== 断点续传检查 ========
existing_labels = {}
if os.path.exists(output_file):
    print("🔄 发现已有标签文件，加载已完成的...")
    with open(output_file, "r", encoding="utf-8") as f:
        existing_labels = json.load(f)
    print(f"   已完成: {len(existing_labels)}/{len(clusters)}")

cluster_labels = existing_labels.copy()

# ======== 生成标签 ========
remaining = [cid for cid in sorted(clusters.keys()) if str(cid) not in cluster_labels and cid not in cluster_labels]

print(f"\n🏷️  待生成: {len(remaining)} 个clusters (每cluster {samples_per_cluster}个样本)")

for cluster_id in tqdm(remaining, desc="生成标签"):
    texts = clusters[cluster_id]

    # 抽样并截断
    sample_texts = random.sample(texts, min(samples_per_cluster, len(texts)))
    sample_texts = [t[:max_text_len].replace('\n', ' ') for t in sample_texts]

    # 生成
    label = generate_label(cluster_id, sample_texts)
    cluster_labels[cluster_id] = label

    print(f"   Cluster {cluster_id}: {label}")

    # 每5个保存一次（防崩溃丢失）
    if len(cluster_labels) % 5 == 0:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(cluster_labels, f, ensure_ascii=False, indent=2)

# ======== 最终保存 ========
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(cluster_labels, f, ensure_ascii=False, indent=2)

print(f"\n{'=' * 50}")
print(f"✅ 完成! 共 {len(cluster_labels)} 个标签")
print(f"💾 保存到: {output_file}")
print("\n标签列表:")
for cid in sorted(cluster_labels.keys())[:10]:
    print(f"  Cluster {cid}: {cluster_labels[cid]}")