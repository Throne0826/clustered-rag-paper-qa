import os
import json
import numpy as np
import torch
import re
from sentence_transformers import SentenceTransformer
from tqdm import tqdm

# ======== 配置 ========

input_file = "chunks.jsonl"
output_file = "chunks_with_emb.jsonl"

model_name = "BAAI/bge-large-en"

batch_size = 64
device = "cpu"

if torch.cuda.is_available():
    device = "cuda"
    batch_size = 128

print(f"🖥️ Device: {device}")

# ======== 加载模型 ========

print(f"Loading model: {model_name}")
model = SentenceTransformer(model_name, device=device)

# ======== 文本清洗 ========

def clean_text(text):
    text = re.sub(r"\s+", " ", text)
    return text.strip()

# ======== 已处理chunk检查 ========

processed_ids = set()

if os.path.exists(output_file):

    print("Checking existing output...")

    with open(output_file, "r", encoding="utf-8") as f:
        for line in f:
            try:
                data = json.loads(line)
                processed_ids.add(data["chunk_id"])
            except:
                pass

print("Processed:", len(processed_ids))

# ======== 读取数据 ========

chunks_data = []

with open(input_file, "r", encoding="utf-8") as f:

    for line in f:

        data = json.loads(line)

        if data["chunk_id"] in processed_ids:
            continue

        text = clean_text(data["text"])

        if len(text) < 30:
            continue

        data["text"] = text

        chunks_data.append(data)

print("To process:", len(chunks_data))

# ======== 生成embedding ========

total_batches = (len(chunks_data) + batch_size - 1) // batch_size

with open(output_file, "a", encoding="utf-8") as out_f:

    for i in tqdm(range(total_batches)):

        start = i * batch_size
        end = min((i + 1) * batch_size, len(chunks_data))

        batch = chunks_data[start:end]

        # ⭐ BGE 必须加 passage:
        texts = ["passage: " + item["text"] for item in batch]

        embeddings = model.encode(
            texts,
            batch_size=len(texts),
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True
        )

        for j, chunk in enumerate(batch):

            result = {
                "chunk_id": chunk["chunk_id"],
                "paper_title": chunk.get("paper_title", ""),
                "category": chunk.get("category", ""),
                "page_number": chunk.get("page_number", 0),
                "text": chunk["text"],
                "embedding": embeddings[j].tolist()
            }

            out_f.write(json.dumps(result, ensure_ascii=False) + "\n")

print("Embedding generation finished")